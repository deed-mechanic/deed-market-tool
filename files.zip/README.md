# DEED MOTORS — 市場価格調査ツール

UNEGUI.MNの実績価格データを元にしたモンゴル中古車市場調査ツールです。

---

## 📁 ファイル構成

```
deed-market-tool/
├── index.html                    ← ツール本体（触らない）
├── data/
│   └── prices.json               ← ★ 毎月ここだけ更新する
├── .github/
│   └── workflows/
│       └── deploy.yml            ← 自動デプロイ設定（触らない）
└── README.md                     ← このファイル
```

---

## 🚀 初回セットアップ（一度だけ）

### 1. GitHubリポジトリを作成
1. https://github.com にアクセスしてログイン
2. 右上の「＋」→「New repository」
3. リポジトリ名: `deed-market-tool`（なんでもOK）
4. **Public**を選択 → 「Create repository」

### 2. ファイルをアップロード
1. 「uploading an existing file」をクリック
2. このフォルダの中身をすべてドラッグ＆ドロップ
   - `.github/` フォルダごと含めること
3. 「Commit changes」をクリック

### 3. GitHub Pagesを有効化
1. リポジトリの「Settings」タブ
2. 左メニュー「Pages」
3. Source: **「GitHub Actions」**を選択
4. 数分待つと自動でURLが発行される

**完成URL例:** `https://あなたのID.github.io/deed-market-tool/`

---

## 🔄 毎月の更新手順（5〜10分）

### ステップ1: UNEGUI.MNで価格を確認
1. https://www.unegui.mn にアクセス
2. 対象車種を検索
3. 最近の掲載価格をメモ

### ステップ2: `prices.json` を編集
**GitHubのウェブ画面で直接編集できます：**
1. リポジトリの `data/prices.json` をクリック
2. 右上の鉛筆アイコン（✏️）をクリック
3. 価格データを修正・追加
4. **必ず `"updated_at"` の日付も更新する**（例: `"2025-07"`）

```json
{
  "meta": {
    "updated_at": "2025-07",   ← ここを毎月変える
    ...
  },
  ...
}
```

### ステップ3: コミット（保存）
1. 画面下の「Commit changes」をクリック
2. 数分でサイトに自動反映される ✅

---

## ✏️ データの追加・変更方法

### 価格データの形式（1件のサンプル）
```json
{"year":2020, "drive":"4WD", "mileage":"72,000 km", "color":"白", "import_year":2022, "price":42.0}
```

| フィールド | 説明 | 例 |
|---|---|---|
| `year` | 生産年 | `2020` |
| `drive` | 駆動方式 | `"4WD"` または `"2WD"` |
| `mileage` | 走行距離（表示用文字列） | `"72,000 km"` |
| `color` | 色（日本語） | `"白"`, `"黒"`, `"銀"`, `"グレー"` など |
| `import_year` | モンゴル入荷年 | `2022` |
| `price` | 価格（сая ₮ / 百万トゥグルグ） | `42.0` |

### 新しい車種を追加する場合
`"models"` セクションにモデル情報を追加し、`"prices"` セクションにデータを追加します。
キー形式は `"メーカー|モデルスラグ"` です（例: `"toyota|new-model"`）。

---

## ❓ トラブルシューティング

| 症状 | 原因 | 対処 |
|---|---|---|
| ページが表示されない | GitHub Pages未設定 | Settings→Pagesを確認 |
| データが古いまま | キャッシュ | ブラウザをハードリロード（Ctrl+Shift+R） |
| 読み込みエラー | JSON書式ミス | JSONバリデーターで確認（https://jsonlint.com）|
| デプロイが動かない | Actionsの権限 | Settings→Actions→General→Read and write permissions |
